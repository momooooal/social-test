# Threads 洞察擷取器 1.1

用途：Threads Insights 沒有方便匯出、頁面文字也不好複製時，直接讀目前已登入頁面已載入的 DOM，送進「社群效益分析 Dashboard」。

## 安裝
1. 解壓縮此資料夾。
2. Chrome 開啟 `chrome://extensions/`。
3. 開啟「開發人員模式」。
4. 按「載入未封裝項目」，選這個資料夾。

## 使用
1. 開啟 `https://www.threads.com/insights?hl=zh-tw` 並登入。
2. 先捲動頁面，讓要分析的內容載入。
3. 點擴充套件 → **① 擷取目前 Threads 洞察**。
4. 切到你的「社群效益分析 Dashboard → 資料中心」。
5. 再點擴充套件 → **② 送入目前 Dashboard**。
6. Dashboard 會出現匯入預覽，確認後按「確認合併」。

也可以按「另存 JSON 備份」，再用 Dashboard 的 JSON 匯入。

此工具不讀 Chrome 密碼、不輸出 Cookie、不輸出 Access Token。它只讀目前 Threads Insights 已經顯示／載入在頁面 DOM 裡的文字與貼文連結。
