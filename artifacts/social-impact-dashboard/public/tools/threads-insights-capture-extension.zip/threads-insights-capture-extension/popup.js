const captureButton = document.getElementById('capture');
const sendButton = document.getElementById('send');
const downloadButton = document.getElementById('download');
const status = document.getElementById('status');
const STORAGE_KEY = 'socialImpactThreadsLastCapture';

function say(text, type='') { status.textContent = text; status.className = `status ${type}`; }
async function activeTab() { const [tab] = await chrome.tabs.query({active:true,currentWindow:true}); return tab; }

function extractThreadsPage() {
  const normalize = (s) => (s || '').replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').trim();
  const hrefOf = (a) => { try { return new URL(a.getAttribute('href') || '', location.href).href; } catch { return ''; } };
  const metricRe = /(views?|瀏覽|觀看|likes?|按讚|replies?|回覆|留言|reposts?|轉發|quotes?|引用)/i;
  const seen = new Set();
  const posts = [];

  const addBlock = (node, href='') => {
    if (!node) return;
    const context = normalize(node.innerText || node.textContent || '');
    if (!context || context.length < 20 || context.length > 9000 || !metricRe.test(context)) return;
    const cleanHref = href ? href.split('?')[0].replace(/\/$/,'') : '';
    const key = cleanHref || context.slice(0,700);
    if (seen.has(key)) return;
    seen.add(key);
    posts.push({href:cleanHref, context});
  };

  // First choice: post permalinks. Walk upward until the metrics around that post are included.
  const anchors = [...document.querySelectorAll('a[href]')]
    .map(a => ({a, href:hrefOf(a)}))
    .filter(x => /threads\.com\/(?:@[^/]+\/)?post\//i.test(x.href));
  for (const {a,href} of anchors) {
    let node = a, best = a;
    for (let i=0;i<10 && node;i++,node=node.parentElement) {
      const text = normalize(node.innerText || node.textContent || '');
      if (metricRe.test(text) && text.length < 9000) { best=node; if(text.length>100) break; }
    }
    addBlock(best,href);
  }

  // Fallback for Insights layouts that do not expose a permalink in each row.
  const elements = [...document.querySelectorAll('article,[role="row"],[role="listitem"],main div')];
  for (const el of elements) {
    const text = normalize(el.innerText || el.textContent || '');
    if (text.length < 35 || text.length > 2400 || !metricRe.test(text)) continue;
    const labels = (text.match(/views?|瀏覽|觀看|likes?|按讚|replies?|回覆|留言|reposts?|轉發|quotes?|引用/gi) || []).length;
    if (labels < 2) continue;
    const link = [...el.querySelectorAll('a[href]')].map(hrefOf).find(h => /threads\.com\/(?:@[^/]+\/)?post\//i.test(h)) || '';
    addBlock(el,link);
  }

  return {
    captureType:'threads-insights-capture', schemaVersion:2, capturedAt:new Date().toISOString(), sourceUrl:location.href,
    title:document.title, pageText:normalize(document.body?.innerText || document.documentElement?.innerText || ''), posts
  };
}

captureButton.addEventListener('click', async () => {
  captureButton.disabled = true; say('正在讀取 Threads Insights…');
  try {
    const tab = await activeTab();
    if (!tab?.id || !/^https:\/\/(www\.)?threads\.com\/insights/i.test(tab.url || '')) throw new Error('請先在目前分頁開啟 https://www.threads.com/insights?hl=zh-tw');
    const [{result}] = await chrome.scripting.executeScript({target:{tabId:tab.id},func:extractThreadsPage});
    if (!result?.pageText) throw new Error('目前頁面沒有可擷取內容，請確認已登入且洞察頁已載入。');
    await chrome.storage.local.set({[STORAGE_KEY]:result});
    say(`擷取完成：辨識 ${result.posts?.length || 0} 個內容區塊。現在切回 Dashboard「資料中心」，再按一次擴充套件的②。`,'ok');
  } catch (e) { say(e instanceof Error ? e.message : String(e),'err'); }
  finally { captureButton.disabled = false; }
});

sendButton.addEventListener('click', async () => {
  sendButton.disabled = true; say('正在送入目前頁面…');
  try {
    const stored = await chrome.storage.local.get(STORAGE_KEY); const payload = stored[STORAGE_KEY];
    if (!payload) throw new Error('還沒有擷取資料。先到 Threads Insights 按①。');
    const tab = await activeTab(); if (!tab?.id) throw new Error('找不到目前分頁。');
    if (/^https:\/\/(www\.)?threads\.com/i.test(tab.url || '')) throw new Error('現在仍在 Threads。請切到「社群效益分析 → 資料中心」再按②。');
    await chrome.scripting.executeScript({target:{tabId:tab.id},func:(data)=>{window.postMessage({type:'SOCIAL_IMPACT_THREADS_CAPTURE',payload:data},'*');},args:[payload]});
    say('已送出。Dashboard 上方應該會直接出現 Threads 匯入預覽。','ok');
  } catch(e) { say(e instanceof Error ? e.message : String(e),'err'); }
  finally { sendButton.disabled=false; }
});

downloadButton.addEventListener('click', async () => {
  try {
    const stored=await chrome.storage.local.get(STORAGE_KEY); const payload=stored[STORAGE_KEY];
    if(!payload) throw new Error('還沒有擷取資料。');
    const url='data:application/json;charset=utf-8,'+encodeURIComponent(JSON.stringify(payload,null,2));
    const stamp=new Date().toISOString().replace(/[:.]/g,'-');
    await chrome.downloads.download({url,filename:`threads-insights-${stamp}.json`,saveAs:false}); say('已另存 JSON 備份。','ok');
  } catch(e){say(e instanceof Error?e.message:String(e),'err');}
});
